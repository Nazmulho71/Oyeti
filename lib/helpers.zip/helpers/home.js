import {_categoriesUrl} from '../../lib/api/baseUrls'
import {_getAllCategoriesAndStore} from './common'

export const _getCategoriesFun = async () => {
  try {
      await _getAllCategoriesAndStore()
  } catch (error) {
      console.log(error)
  }
}

export const _setIndexFun = (isUp, currentIndex, storeData,  setIndex) => {
    let index = currentIndex
    if (storeData.assets) {
      if (isUp ) {
        index = index + 1
        if (storeData.assets && index == storeData.assets.length) {
          index = 0
        }
      }else{
        index = index - 1
        if (index < 0) {
          index = storeData.assets ?  storeData.assets.length - 1 : 0
        }
      }
    }
    setIndex(index)
}

export const _handleTouchEndFun = (heightOver, touchStart, touchEnd, assets, currentIndex, _setIndex, setHeightOver) => {
  let height = heightOver

  if (touchStart - touchEnd > 150) {
    height = height - 100
    if (assets && currentIndex == assets.length - 1) {
      return
    }
    _setIndex(true)
  }

  if (touchStart - touchEnd < -150) {
    height = height + 100
    if (currentIndex == 0) {
      return
    }
    _setIndex(false)
  }
  
  setHeightOver(height)
}