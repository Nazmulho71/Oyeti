import {login} from '../../middleware/auth'
import cookies from 'js-cookie'
import {OTPTypes} from '../../lib/enums'
import axios from 'axios'
let otpBaseUrl = process.env.NEXT_PUBLIC_OYETI_BASE_URL

const _isValidNo = (phone) => {
    if (!phone || phone.length != 10 ) {
        return "enter a valid phone no"
    }

    let test = parseFloat(phone)
    if (isNaN(test)) {
        return "enter a valid phone no"
    }

    return null

}
export const _setPhone = (self) => {
    let {phone} = self.state
    let _isValidError = _isValidNo(phone)
    if (_isValidError) {
        self.setState({
            errors: _isValidError
        })
        return
    }
    generateOTP(self)
}

export const generateOTP = async (self) => {
    try {
        let {submiting, phone, otpType} =  self.state
        if (submiting) {
            return
        }

        let _isValidError = _isValidNo(phone)
        if (_isValidError) {
            self.setState({
                errors: _isValidError
            })
            return
        }

        self.setState({
            submiting: true,
            errors: null,
            otp: ''
        })

        let url =  otpType == OTPTypes.WhatsApp ? "api/v1/users/generate_whapp_otp"  : "api/v1/users"
        let data = {
            url: otpBaseUrl + url,
            payload: {
                phone
            }
        }
        await axios.post('/api/v1', data)
        self.setState({
            submiting: false,
            phoneSet: true,
            errors: null,
        })
    } catch (error) {
        self.setState({
            submiting: false,
            errors: "server error",
        })
    }
}

export const submitOTP = async (self) => {
    try {
        
        let {submiting, phone, otp, redirect} =  self.state
        if (submiting || !phone) {
            return
        }

        let _isValidError = _isValidNo(phone)
        if (_isValidError) {
            self.setState({
                errors: _isValidError
            })
            return
        }

        self.setState({
            submiting: true,
            errors: "",
        })

        let url =  otpBaseUrl + "api/v1/users/sign_in"
        let payload = {
            url,
            payload: {
                phone,
                otp
            }
        }
        
        let response = await axios.post('/api/v1', payload)
        cookies.set('phone', phone)
        let {auth, data} = response.data
        cookies.set('app_id', data.user.app_id)
        localStorage.setItem('user', JSON.stringify(data.user))
        login(auth, redirect)
    } catch (error) {
        console.log(error)
        self.setState({
            submiting: false,
            errors: "otp is not valid",
        })
    }
}

export const _getLable = (phoneSet, submiting) => {
    if (submiting) {
        return "Wait..."
    }
    if (phoneSet) {
        return "Continue"
    }else{
        return "Request OTP"
    }
}