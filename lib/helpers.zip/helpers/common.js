import {_categoriesUrl, _menuUrl} from '../../lib/api/baseUrls'
import database from '../../lib/enums/db'
import axios from 'axios'
import {_intiatDataBase} from './db'

const _updateAdd =  (product, objectStore) => {
    objectStore.get(product.id).onsuccess = event => {
        let result = event.target.result
        if (result) {
            objectStore.put(product).onsuccess = e => {
                console.log("updated")
            }
        }else{
            objectStore.add(product).onsuccess = e => {
                console.log("added")
            }
        }
    }
}


export const _getLocalCategory = () => {
    return new Promise (async (res, reject) => {
        try {
            let db = window.db
            if (!db) {
                db = await _intiatDataBase()
            }

            let objectStore = db.transaction([database.CATEGORIES_DB], "readwrite").objectStore(database.CATEGORIES_DB)
            objectStore.getAll().onsuccess = function(event) {
                return res(event.target.result)
            } 
        } catch (error) {
            console.log(error)
            reject([])
        }
    })
}


export const _getAllCategoriesAndStore = async (setCategories) => {
    return new Promise (async (res, reject) => {
        try {
            let localRes = await _getLocalCategory()
            if (localRes.length > 0) {
                if (setCategories) {
                    setCategories(localRes)
                }
            }

            let slug = "slug"
            let url = _categoriesUrl(slug)
            let response = await axios.get(url)
            let categories = response.data.data
            if (setCategories) {
                setCategories(categories)
            }

            let db = window.db
            if (!db) {
                db = await _intiatDataBase()
            }

            let objectStore = db.transaction([database.CATEGORIES_DB], "readwrite").objectStore(database.CATEGORIES_DB)
            categories.forEach(function(cat) {
                _updateAdd(cat, objectStore)
            })
            return res(categories)
        } catch (error) {
            console.log(error)
            return reject([])
        }
    })
}


export const _getLocalProducts = () => {
    return new Promise (async (res, reject) => {
        try {
            let db = window.db
            if (!db) {
                db = await _intiatDataBase()
            }

            let objectStore = db.transaction([database.PRODUCTS_DB], "readwrite").objectStore(database.PRODUCTS_DB)
            objectStore.getAll().onsuccess = function(event) {
                return res(event.target.result)
            } 
        } catch (error) {
            console.log(error)
            reject([])
        }
    })
}



export const _getAllProducts = async (setProducts = null, catId = 0) => {
    return new Promise (async (res, reject) => {
        try {
            let localRes = await _getLocalProducts()
            if (localRes.length > 0) {
                if (setProducts) {
                    setProducts(localRes)
                }
                
            }
            let slug = "slug"
            let url = _menuUrl(slug) + '&cat_id='+catId
            let response = await axios.get(url)
            let products = response.data.data.products

            if (setProducts) {
                setProducts(products)
            }

            let db = window.db
            if (!db) {
                db = await _intiatDataBase()
            }

            let objectStore = db.transaction([database.PRODUCTS_DB], "readwrite").objectStore(database.PRODUCTS_DB)
            products.forEach(function(product) {
                _updateAdd(product, objectStore)
            })
            return res(products)
        } catch (error) {
            console.log(error)
            return reject([])
        }
    })
}


export const _pushMenu =  ({flowId, mid, tableNo}) => {
    // mid = "25BCABC4"
    let url = process.env.NEXT_PUBLIC_OYETI_BASE_URL
    mid = "17849628"
    let token = tableNo ? btoa(`${flowId}/${mid}/${tableNo}`) : btoa(`${flowId}/${mid}`)
    let baseURL = url + `store/${token}/loading`
    window.location.href = baseURL
}

export const _navigatePage =  () => {
    let url = process.env.NEXT_PUBLIC_OYETI_BASE_URL
    let baseURL = url + `pay`
    window.location.replace(baseURL)
}



export const _isValidNumberInput = (newPhone, oldPhone, maxLength) => {
    let pattern = /^\d+$/
   
    if (pattern.test(newPhone) && newPhone) {
        if(!oldPhone && newPhone == 0){
            return false
        }

        if(oldPhone && newPhone.length > maxLength){
            return false
        }

        let test = parseFloat(newPhone)

        if (isNaN(test)) {
            return false
        }

        return true
    }else{
        if(newPhone == "") {
            return true
        }
    }

    return false
}


