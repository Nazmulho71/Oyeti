let dbName = process.env.NEXT_PUBLIC_LOCAL_DATABASE
import database from '../enums/db'

export const _intiatDataBase = () =>  {

    return new Promise((response , reject) => {
        let request = indexedDB.open(dbName, 6)

        request.onerror = () => {
            console.log("Why didn't you allow my web app to use IndexedDB?!")
        }

        request.onupgradeneeded = e => {
            let localDb = e.target.result

            if (!localDb.objectStoreNames.contains(database.CARTS_DB)) {
                let store = localDb.createObjectStore(database.CARTS_DB,{keyPath: 'id'})
                store.createIndex('id', 'id', { unique: true })
            }

            if (!localDb.objectStoreNames.contains(database.CATEGORIES_DB)) {
                let store = localDb.createObjectStore(database.CATEGORIES_DB,{keyPath: 'id'})
                store.createIndex('id', 'id', { unique: true })
            }

            if (!localDb.objectStoreNames.contains(database.PRODUCTS_DB)) {
                let store = localDb.createObjectStore(database.PRODUCTS_DB,{keyPath: 'id'})
                store.createIndex('id', 'id', { unique: true })
            }
        }
        
        request.onsuccess = function(event) {
            const db = event.target.result
            window.db = db
            return response(db)
        }

        request.onerror = function(e) {
            console.log('onerror!')
            return reject(null)
        }

    })

    
    
  }



