
import database from '../../lib/enums/db'
import { _getAllCategoriesAndStore, _getAllProducts, _getLocalProducts} from './common'
import { _fetchMenu , baseLocalURL} from "../api/baseUrls"
import {_intiatDataBase} from './db'
import { FilterList} from '../enums'
import startCase from 'lodash/startCase'
import axios from 'axios'

export const _getCategoriesFun = async (setCategories) => {
    try {
        await _getAllCategoriesAndStore(setCategories)
    } catch (error) {
        console.log(error)
    }
}

export const _getProductsFun = async setProducts => {
    try {
        await _getAllProducts(setProducts)
    } catch (error) {

    }
}

export const _pushItemFun = (item, carts, setCarts) => {
    let findItem = carts.find(cart => cart.id == item.id)
    if (typeof findItem === 'undefined') {
        let cartsItems = [...carts]
        cartsItems.push(item)
        setCarts(cartsItems)
    }else{
        let items = carts.map(cart => {
            if (cart.id == item.id) {
                cart.added_quantity = item.added_quantity
            }
            return cart
        })
        setCarts(items)
    }
}

export const summery = carts => {
    let totalQuantity = 0
    let totalAmount = 0
    for (let index = 0; index < carts.length; index++) {
        const element = carts[index]
        totalQuantity += element.added_quantity
        totalAmount  += (element.added_quantity * element.price)
    }
    return {totalQuantity, totalAmount}
}


export const _isAddedToCart = (item, carts) => {
    let findItem = carts.find(cart => cart.id == item.id)
    return findItem ? findItem : item
}


export const _getCartsFun = async (setCarts) => {
    setTimeout(async () => {
        let db = window.db
        if (!db) {
            db = await _intiatDataBase()
        }
        let objectStore = db.transaction(database.CARTS_DB).objectStore(database.CARTS_DB)
        objectStore.getAll().onsuccess = function(event) {
            setCarts(event.target.result)
        }
    }, 1000)
}

export const _addCartFun = async (item, carts, setCarts, isAdd = false) => {

    if (isAdd) {
        item.added_quantity = item.added_quantity + 1
    }else{
        item.added_quantity = item.added_quantity - 1
    }

    let db = window.db
    if (!db) {
        db = await _intiatDataBase()
    }
  
    let objectStore = db.transaction([database.CARTS_DB], "readwrite").objectStore(database.CARTS_DB)
    objectStore.get(item.id).onsuccess = event => {
        let result = event.target.result
        if (result) {
            if (item.added_quantity < 1) {
                objectStore.delete(item.id).onsuccess = e => {
                    const filteredItems = carts.filter(cart => item.id !== cart.id)
                    setCarts(filteredItems)
                    console.log("delete")
                }
            }else{
                objectStore.put(item).onsuccess = e => {
                    console.log("updated")
                    _pushItemFun(item, carts, setCarts)
                }
            }
        }else{
            objectStore.add(item).onsuccess = e => {
                console.log("added")
                _pushItemFun(item, carts, setCarts)
            }
        }
    }
}


export const _filterProducts = async (setProducts, catID, vegOnly, includeEgg) => {
    let filterProducts = await _getLocalProducts() 
    if (catID !== null) {
        if (catID == FilterList.BEST_SELLER_ID) {
            filterProducts = filterProducts.filter(prod => prod.is_best_seller)
        }else{
            filterProducts = filterProducts.filter(prod => prod.category_name == catID)
        }
    }

    if (vegOnly && includeEgg) {
        filterProducts = filterProducts.filter(prod => prod.item_type == FilterList.VEG_ONLY || prod.item_type == FilterList.INCLUDE_EGG )
    }else if (vegOnly && !includeEgg){
        filterProducts = filterProducts.filter(prod => prod.item_type == FilterList.VEG_ONLY )
    }else if (!vegOnly && includeEgg){
        filterProducts = filterProducts.filter(prod => prod.item_type == FilterList.INCLUDE_EGG )
    }

    setProducts(filterProducts)
}

export const isVegOnly = product => {
    return product.item_type == FilterList.VEG_ONLY
}

export const _searchProducts = async (text, setSearchProducts) => {
    if (!text) {
        setSearchProducts([])
        return
    }
    let filterProducts = await _getLocalProducts() 
    filterProducts = filterProducts.filter(product => {
        let index = product.name.toLowerCase().search(text.toLowerCase())
        if (index > 0) {
            return product
        }
    })
    setSearchProducts(filterProducts)
}

export const _fetchMenuProducts = async (mid, setProducts, setCategories) => {
    try {
        let url = _fetchMenu()
        const response = await axios.post(baseLocalURL, {
          payload: {
                mid
            },
            url
        })

        let itemLists = response.data.data.data.item_lists

        let categories = []
        let products = []

        for (let index = 0; index < itemLists.length; index++) {
            const category = itemLists[index]
            categories.push(category.category_name)
            for (let pIndex = 0; pIndex < category.category_items.length; pIndex++) {
                let product = category.category_items[pIndex]
                product = {...product, category_name: category.category_name}
                products.push(product)
            }
            
        }

        categories.unshift('best seller')
        setCategories(categories)
        setProducts(products)
    } catch (error) {
        console.log(error)
    }
}

export const _titleCase = title => {
    return startCase(title)
}