import * as React from "react";

function LocationIcon(props) {
  return (
    <svg
      data-name="Group 2969"
      width={9}
      height={12}
      viewBox="0 0 9.908 14"
      {...props}
    >
      <path
        data-name="Path 49172"
        d="M4.938 0a4.958 4.958 0 014.97 4.938c0 2.7-2.516 6.8-4.473 8.852a.657.657 0 01-.963 0C2.516 11.74 0 7.641 0 4.938A4.931 4.931 0 014.938 0zm0 2.112a2.826 2.826 0 11-2.826 2.826 2.817 2.817 0 012.826-2.826z"
        fill={props.fill || "#fe346e"}
        fillRule="evenodd"
      />
    </svg>
  );
}

export default LocationIcon;
