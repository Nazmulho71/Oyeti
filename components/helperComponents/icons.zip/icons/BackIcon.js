import * as React from "react"

function BackIcon(props) {
	return (
		<svg viewBox="0 0 24 24" height={24} width={24} {...props} fill="#15171b">
			<g data-name="Layer 2">
				<path
					d="M19 11H7.14l3.63-4.36a1 1 0 10-1.54-1.28l-5 6a1.19 1.19 0 00-.09.15c0 .05 0 .08-.07.13A1 1 0 004 12a1 1 0 00.07.36c0 .05 0 .08.07.13a1.19 1.19 0 00.09.15l5 6A1 1 0 0010 19a1 1 0 00.64-.23 1 1 0 00.13-1.41L7.14 13H19a1 1 0 000-2z"
					data-name="arrow-back"
				/>
			</g>
		</svg>
	)
}

export default BackIcon
