import * as React from "react"

function StarIcon(props) {
	return (
		<svg width={12} height={10} viewBox="10 10 28 28" {...props} fill="#400082">
			<path
				fill="#FFA91B"
				d="M0 18.1h19.1L25 0l5.9 18.1H50L34.6 29.3l5.9 18.1-15.4-11.2L9.7 47.4l5.9-18.1L.2 18.1z"
				data-reactid=".0.1.m.1.0.0.0.$star-0"
			/>
		</svg>
	)
}

export default StarIcon;
