import * as React from "react"

function SvgComponent(props) {
	return (
		<svg width={18.35} height={17.748} viewBox="0 0 18.35 17.748" {...props}>
			<path
				data-name="Rectangle 441"
				fill="#becdff"
				d="M12.334 14.439h1.805v3.008h-1.805z"
			/>
			<path
				data-name="Path 588"
				d="M16.247 12.033V9.626h-1.2v2.407a.9.9 0 00-.9.9v4.51h3v-4.512a.9.9 0 00-.9-.898z"
				fill="#ffd2a5"
			/>
			<path
				data-name="Path 49157"
				d="M16.245 12.033V9.626h-1.2v2.407h1.2z"
				fill="#d30303"
			/>
			<path
				data-name="Path 49156"
				d="M15.342 13.537h1.8v2.707h-1.8z"
				fill="#fdb62f"
			/>
			<path
				data-name="Path 589"
				d="M13.236 13.236a.9.9 0 01.9.9v.3h-1.8v-.3a.9.9 0 01.9-.9z"
				fill="#414141"
			/>
			<g data-name="Group 91" fill="#ff2f19">
				<path
					data-name="Path 590"
					d="M3.005 13.537a.644.644 0 00.535-1l-.535-.8-.535.8a.644.644 0 00.535 1z"
				/>
				<path
					data-name="Path 591"
					d="M6.017 13.537a.644.644 0 00.535-1l-.535-.8-.535.8a.644.644 0 00.535 1z"
				/>
				<path
					data-name="Path 592"
					d="M9.025 13.537a.644.644 0 00.535-1l-.535-.8-.535.8a.644.644 0 00.535 1z"
				/>
			</g>
			<g data-name="Group 92">
				<path
					data-name="Path 593"
					d="M10.528 16.244h-.6v-1.2h-1.2v-.6h1.5a.3.3 0 01.3.3z"
					fill="#707070"
				/>
				<path
					data-name="Path 594"
					d="M2.106 16.244h-.6v-1.5a.3.3 0 01.3-.3h1.5v.6h-1.2z"
					fill="#707070"
				/>
				<path
					data-name="Rectangle 443"
					fill="#707070"
					d="M5.715 14.439h.602v1.805h-.602z"
				/>
				<path
					data-name="Rectangle 444"
					fill="#bfbfbf"
					d="M.902 16.244H11.13v1.203H.902z"
				/>
			</g>
			<path
				data-name="Path 595"
				d="M9.566 10.529h-7.1A2.166 2.166 0 01.3 8.363V6.919h11.432v1.444a2.166 2.166 0 01-2.166 2.166z"
				fill="#4398d1"
			/>
			<path
				data-name="Path 596"
				d="M11.732 7.22h.9l.728-1.2a.6.6 0 01.514-.3h3.872a.6.6 0 01.6.6.6.6 0 01-.6.6h-3.438a.3.3 0 00-.259.147l-.815 1.357h-1.5"
				fill="#126099"
			/>
			<path
				data-name="Path 597"
				d="M3.309 4.813h-.6a1.2 1.2 0 011.2-1.2v.6a.6.6 0 00-.6.6z"
				fill="#ff9100"
			/>
			<circle
				data-name="Ellipse 83"
				cx={0.602}
				cy={0.602}
				transform="translate(6.618 3.61)"
				fill="#ff2f19"
				r={0.602}
			/>
			<g data-name="Group 93" fill="#ff9100">
				<path
					data-name="Path 598"
					d="M4.814 2.406h-.6a.6.6 0 00-1.2 0h-.6a1.204 1.204 0 112.407 0z"
				/>
				<path
					data-name="Path 599"
					d="M9.329 4.512v-.3a.9.9 0 01.9-.9.9.9 0 01.9.9v.3z"
				/>
			</g>
			<path
				data-name="Path 600"
				d="M9.626 6.017v-.6a.3.3 0 00.3-.3v-.6h.6v.6a.9.9 0 01-.9.9z"
				fill="#ff9100"
			/>
			<g data-name="Group 94" transform="translate(.902)" fill="#ff2f19">
				<path
					data-name="Path 601"
					d="M4.809 6.016a1.2 1.2 0 01-1.2-1.2h.6a.6.6 0 00.6.6z"
				/>
				<circle
					data-name="Ellipse 84"
					cx={0.602}
					cy={0.602}
					transform="translate(4.512)"
					r={0.602}
				/>
				<path
					data-name="Path 602"
					d="M.902 5.415a.9.9 0 01-.9-.9.9.9 0 01.9-.9z"
				/>
				<path
					data-name="Path 603"
					d="M6.317 2.406v-.6a.6.6 0 00.6-.6h.6a1.2 1.2 0 01-1.2 1.2z"
				/>
				<path data-name="Rectangle 445" d="M4.211 2.707h.602v.602h-.602z" />
			</g>
			<path
				data-name="Rectangle 446"
				fill="#ff9100"
				d="M9.325 1.504h.602v.602h-.602z"
			/>
			<path
				data-name="Rectangle 447"
				fill="#ff2f19"
				d="M8.122 5.415h.602v.602h-.602z"
			/>
			<path
				data-name="Rectangle 448"
				fill="#414141"
				d="M0 17.147h18.049v.602H0z"
			/>
			<path
				data-name="Path 604"
				d="M.872 9.854a2.21 2.21 0 001.587.658h7.072a2.093 2.093 0 002.156-2.023V7.14h-.3C8.389 9.106 5.993 9.668.872 9.854z"
				fill="#3e8cc7"
			/>
			<path
				data-name="Path 605"
				d="M1.805 6.919v1.522a.584.584 0 00.584.584h.018a.6.6 0 00.6-.6.6.6 0 01.6-.6.6.6 0 01.6.6v.6a.6.6 0 101.2 0V6.919z"
				fill="#6aa9d4"
			/>
		</svg>
	)
}

export default SvgComponent
