import * as React from "react"
import {BaseStyles} from '../BaseStyles';

function CloseCircleIcon(props) {
	return (
		<svg width={16} height={16} viewBox="0 0 24 24" fill={BaseStyles.purple}>
			<path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm4.151 17.943l-4.143-4.102L7.891 18l-1.833-1.833 4.104-4.157L6 7.891l1.833-1.833 4.155 4.102L16.094 6l1.849 1.849-4.1 4.141L18 16.094l-1.849 1.849z" />
		</svg>
	)
}

export default CloseCircleIcon
