import * as React from "react"

function RightChevron(props) {
	return (
		<svg width={12} height={10} viewBox="10 10 28 28" {...props} fill={props.fill ? props.fill : '#400082'}>
			<path d="M20 12l-2.83 2.83L26.34 24l-9.17 9.17L20 36l12-12z" />
			<path d="M0 0h48v48H0z" fill="none" />
		</svg>
	)
}

export default RightChevron
