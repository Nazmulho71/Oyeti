import * as React from "react"

function SvgComponent(props) {
  return (
    <svg
      data-name="Group 3581"
      width={50}
      height={35.98}
      viewBox="0 0 50 35.98"
      {...props}
    >
      <text
        transform="translate(25 33.98)"
        fill="#d1d1d1"
        fontSize={10}
        fontFamily="Helvetica"
      >
        <tspan x={-24.722} y={0}>
          {"ACCOUNT"}
        </tspan>
      </text>
      <path
        data-name="Path 49170"
        d="M26.365 0a4.291 4.291 0 014.247 4.247v1.237a4.223 4.223 0 01-1.935 3.548 7.4 7.4 0 015.053 6.989.538.538 0 11-1.075 0 6.29 6.29 0 00-12.58 0 .508.508 0 01-.538.538.508.508 0 01-.537-.538 7.4 7.4 0 015.053-6.989 4.223 4.223 0 01-1.935-3.548V4.247A4.291 4.291 0 0126.365 0zm0 1.075a3.178 3.178 0 00-3.172 3.172v1.237a3.172 3.172 0 006.344 0V4.247a3.178 3.178 0 00-3.172-3.172z"
        fill="#d1d1d1"
      />
    </svg>
  )
}

export default SvgComponent
