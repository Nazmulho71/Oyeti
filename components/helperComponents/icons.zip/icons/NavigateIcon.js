import * as React from "react"

function NavigateIcon(props) {
	return (
		<svg width={12} height={12} viewBox="0 0 15.93 15.93" {...props}>
			<path
				d="M8.073 7.673l-7.344-2c-.958-.261-.976-.713-.027-1.012L15.324.043c.457-.144.709.113.566.566l-4.617 14.622c-.3.943-.75.937-1.012-.027l-2-7.344a.281.281 0 00-.188-.187z"
				fill="white"
				fillRule="evenodd"
			/>
		</svg>
	)
}

export default NavigateIcon
